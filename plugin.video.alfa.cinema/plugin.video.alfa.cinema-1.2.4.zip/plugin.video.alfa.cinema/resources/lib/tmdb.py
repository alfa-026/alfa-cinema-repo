# -*- coding: utf-8 -*-
"""Cliente de metadatos TMDB; no proporciona enlaces de reproducción."""
import json
import urllib.parse
import urllib.request
import urllib.error

BASE = "https://api.themoviedb.org/3"

class TMDBError(Exception):
    pass

def request(path, api_key, language="es-ES", params=None):
    if not api_key:
        raise TMDBError("Configura tu TMDB API Key en Ajustes.")
    query = {"api_key": api_key, "language": language}
    if params:
        query.update(params)
    url = BASE + path + "?" + urllib.parse.urlencode(query)
    req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "ALFA-CINEMA/0.4.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise TMDBError("TMDB HTTP %s. Comprueba la API Key y los límites." % exc.code)
    except Exception as exc:
        raise TMDBError("No se pudo consultar TMDB: %s" % exc)

def search(query, api_key, kind="multi", language="es-ES", page=1):
    if kind not in ("movie", "tv", "multi"):
        kind = "multi"
    return request("/search/" + kind, api_key, language, {"query": query, "page": page, "include_adult": "false"})

def discover_year(year, api_key, kind="movie", language="es-ES", page=1):
    if kind == "tv":
        return request("/discover/tv", api_key, language, {"first_air_date_year": year, "sort_by": "popularity.desc", "page": page})
    return request("/discover/movie", api_key, language, {"primary_release_year": year, "sort_by": "popularity.desc", "page": page})

def image_url(path, size="w500"):
    return "https://image.tmdb.org/t/p/%s%s" % (size, path) if path else ""


def trending(api_key, media_type="all", time_window="week", language="es-ES", page=1):
    if media_type not in ("all", "movie", "tv"):
        media_type = "all"
    if time_window not in ("day", "week"):
        time_window = "week"
    return request("/trending/%s/%s" % (media_type, time_window), api_key, language, {"page": page})

def popular(api_key, media_type="movie", language="es-ES", page=1):
    if media_type == "tv":
        return request("/tv/popular", api_key, language, {"page": page})
    return request("/movie/popular", api_key, language, {"page": page})


def search_multilingual(query, api_key, media_type="multi", languages=None, page=1):
    """Busca en varias configuraciones regionales y elimina duplicados por tipo/ID."""
    languages = languages or ["es-ES", "ca-ES", "en-US"]
    merged = {}
    errors = []
    for lang in languages:
        try:
            data = search(query, api_key, media_type, lang, page)
            for item in data.get("results", []):
                kind = item.get("media_type")
                if kind not in ("movie", "tv"):
                    kind = "movie" if "title" in item else "tv" if "name" in item else None
                item_id = item.get("id")
                if not kind or not item_id:
                    continue
                key = "%s:%s" % (kind, item_id)
                if key not in merged:
                    item["_matched_language"] = lang
                    merged[key] = item
                else:
                    # Keep the record with the richest localized overview/title.
                    old = merged[key]
                    score_old = bool(old.get("overview")) + bool(old.get("title") or old.get("name"))
                    score_new = bool(item.get("overview")) + bool(item.get("title") or item.get("name"))
                    if score_new > score_old:
                        item["_matched_language"] = lang
                        merged[key] = item
        except Exception as exc:
            errors.append("%s: %s" % (lang, exc))
    return list(merged.values()), errors


def details(item_id, media_type, api_key, language="es-ES"):
    if media_type not in ("movie", "tv"):
        media_type = "movie"
    return request("/%s/%s" % (media_type, item_id), api_key, language,
                   {"append_to_response": "videos,credits,external_ids"})

def season_details(tv_id, season_number, api_key, language="es-ES"):
    return request("/tv/%s/season/%s" % (tv_id, season_number), api_key, language,
                   {"append_to_response": "credits,videos"})

def episode_details(tv_id, season_number, episode_number, api_key, language="es-ES"):
    return request("/tv/%s/season/%s/episode/%s" % (tv_id, season_number, episode_number),
                   api_key, language, {"append_to_response": "credits,videos"})

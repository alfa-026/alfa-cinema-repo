# -*- coding: utf-8 -*-
"""Cliente Trakt API v2: OAuth Device Flow, renovación y biblioteca de solo lectura."""
import json
import time
import urllib.parse
import urllib.request
import urllib.error

API = "https://api.trakt.tv"
DEVICE_CODE_URL = API + "/oauth/device/code"
DEVICE_TOKEN_URL = API + "/oauth/device/token"
TOKEN_URL = API + "/oauth/token"

class TraktError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status

def _request(url, method="GET", data=None, client_id=None, token=None):
    headers = {"Content-Type": "application/json", "trakt-api-version": "2"}
    if client_id:
        headers["trakt-api-key"] = client_id
    if token:
        headers["Authorization"] = "Bearer " + token
    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        raise TraktError("Trakt HTTP %s: %s" % (exc.code, detail[:350]), exc.code)
    except Exception as exc:
        raise TraktError("No se pudo conectar con Trakt: %s" % exc)

def request_device_code(client_id):
    if not client_id.strip():
        raise TraktError("Falta el Trakt Client ID en Ajustes.")
    return _request(DEVICE_CODE_URL, "POST", {"client_id": client_id}, client_id=client_id)

def poll_device_token(client_id, device_code, interval, expires_in, progress=None, cancelled=None):
    deadline = time.time() + int(expires_in)
    wait = max(1, int(interval))
    while time.time() < deadline:
        if cancelled and cancelled():
            raise TraktError("Autorización cancelada.")
        time.sleep(wait)
        try:
            result = _request(DEVICE_TOKEN_URL, "POST", {
                "code": device_code, "client_id": client_id,
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code"
            }, client_id=client_id)
            if result.get("access_token"):
                return result
        except TraktError as exc:
            if exc.status in (400, 428):
                pass  # autorización pendiente / código aún no aprobado
            elif exc.status == 429:
                wait = min(wait + 2, 15)
            else:
                raise
        if progress:
            progress()
    raise TraktError("La autorización ha caducado. Vuelve a intentarlo.")

def refresh_token(client_id, refresh):
    if not refresh:
        raise TraktError("No hay refresh token. Vuelve a conectar Trakt.")
    return _request(TOKEN_URL, "POST", {
        "refresh_token": refresh, "client_id": client_id,
        "grant_type": "refresh_token", "redirect_uri": "urn:ietf:wg:oauth:2.0:oob"
    }, client_id=client_id)

def api_get(path, client_id, token):
    return _request(API + path, client_id=client_id, token=token)

def get_user(client_id, token):
    return api_get("/users/me?extended=full", client_id, token)

def get_watchlist(client_id, token, media_type="movies"):
    return api_get("/sync/watchlist/" + media_type, client_id, token)

def get_collection(client_id, token, media_type="movies"):
    return api_get("/sync/collection/" + media_type, client_id, token)

def get_user_lists(client_id, token):
    return api_get("/users/me/lists", client_id, token)

def get_history(client_id, token, media_type="movies"):
    return api_get("/sync/history/" + media_type, client_id, token)

def get_playback(client_id, token):
    return api_get("/sync/playback", client_id, token)

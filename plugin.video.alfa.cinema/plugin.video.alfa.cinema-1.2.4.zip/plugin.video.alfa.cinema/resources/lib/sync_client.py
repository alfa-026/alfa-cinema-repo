# -*- coding: utf-8 -*-
"""Cliente HTTP de sincronización ALFA CINEMA."""
import json
import urllib.request
import urllib.error
import urllib.parse

class SyncError(Exception):
    pass

def _request(base_url, secret, path, method="GET", payload=None):
    if not base_url or not secret:
        raise SyncError("Configura la URL y la clave del servidor en Ajustes.")
    url = base_url.rstrip("/") + path
    headers = {"Accept": "application/json", "X-API-Key": secret, "User-Agent": "ALFA-CINEMA/0.5.0"}
    body = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:250]
        raise SyncError("Servidor de sincronización HTTP %s: %s" % (exc.code, detail))
    except Exception as exc:
        raise SyncError("No se pudo contactar con el servidor: %s" % exc)

def push_progress(base_url, secret, progress):
    return _request(base_url, secret, "/v1/progress", "POST", progress)

def get_progress(base_url, secret, limit=50):
    query = urllib.parse.urlencode({"limit": int(limit)})
    return _request(base_url, secret, "/v1/progress?" + query)

def get_content_progress(base_url, secret, content_key):
    query = urllib.parse.urlencode({"content_key": content_key})
    return _request(base_url, secret, "/v1/progress/by-content?" + query)

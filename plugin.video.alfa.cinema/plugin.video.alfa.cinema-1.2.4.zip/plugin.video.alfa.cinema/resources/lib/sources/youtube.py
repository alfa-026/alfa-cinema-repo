# -*- coding: utf-8 -*-
"""Tráilers mediante el complemento oficial de YouTube para Kodi, si está instalado."""
import xbmcaddon
from .base import SourceProvider

class YouTubeTrailerProvider(SourceProvider):
    provider_id = "youtube_trailers"
    display_name = "YouTube — tráilers"

    def search(self, query, media_type="all", limit=10):
        # YouTube Data API keys y scraping no se incorporan aquí.
        # La búsqueda se delega al complemento oficial de YouTube de Kodi.
        try:
            xbmcaddon.Addon("plugin.video.youtube")
        except Exception:
            return []
        return [{
            "provider": self.provider_id,
            "provider_name": self.display_name,
            "title": "Buscar tráiler de " + query,
            "query": query,
            "action": "youtube_search",
            "id": ""
        }]

    def resolve(self, item):
        return []

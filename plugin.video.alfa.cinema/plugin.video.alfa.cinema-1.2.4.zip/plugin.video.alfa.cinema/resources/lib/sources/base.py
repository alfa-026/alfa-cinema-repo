# -*- coding: utf-8 -*-
"""Contrato común para proveedores de fuentes."""
class SourceProvider(object):
    provider_id = "base"
    display_name = "Proveedor base"

    def search(self, query, media_type="all", limit=20):
        raise NotImplementedError

    def resolve(self, item):
        raise NotImplementedError

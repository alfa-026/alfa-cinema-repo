# -*- coding: utf-8 -*-
"""Internet Archive: búsqueda de vídeos con licencia abierta explícita."""
import json
import urllib.parse
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET

from .base import SourceProvider

SEARCH_URL = "https://archive.org/advancedsearch.php"
META_URL = "https://archive.org/metadata/"

# Solo licencias abiertas explícitas. No se asume que todo Internet Archive
# sea de dominio público.
ALLOWED_LICENSE_MARKERS = (
    "creativecommons.org/publicdomain/zero",
    "creativecommons.org/licenses/by/",
    "creativecommons.org/licenses/by-sa/",
)

class ArchiveProvider(SourceProvider):
    provider_id = "archive"
    display_name = "Internet Archive — licencias abiertas"

    def _get_json(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": "ALFA-CINEMA/0.6.0", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=18) as response:
            return json.loads(response.read().decode("utf-8"))

    def search(self, query, media_type="all", limit=20):
        q = 'mediatype:movies AND title:"%s"' % query.replace('"', ' ').strip()
        params = {
            "q": q,
            "fl[]": ["identifier", "title", "year", "licenseurl", "description"],
            "rows": str(max(1, min(int(limit), 50))),
            "page": "1",
            "output": "json"
        }
        # urllib supports repeated fl[] fields through doseq.
        url = SEARCH_URL + "?" + urllib.parse.urlencode(params, doseq=True)
        data = self._get_json(url)
        docs = data.get("response", {}).get("docs", [])
        results = []
        for doc in docs:
            license_url = str(doc.get("licenseurl", "")).lower()
            if not any(marker in license_url for marker in ALLOWED_LICENSE_MARKERS):
                continue
            identifier = doc.get("identifier")
            if not identifier:
                continue
            results.append({
                "provider": self.provider_id,
                "provider_name": self.display_name,
                "id": identifier,
                "title": doc.get("title", identifier),
                "year": doc.get("year", ""),
                "description": doc.get("description", ""),
                "license": doc.get("licenseurl", ""),
                "web_url": "https://archive.org/details/" + identifier
            })
        return results

    def resolve(self, item):
        identifier = item.get("id")
        if not identifier:
            return []
        data = self._get_json(META_URL + urllib.parse.quote(identifier, safe=""))
        files = data.get("files", [])
        candidates = []
        for file_info in files:
            name = file_info.get("name", "")
            fmt = str(file_info.get("format", "")).lower()
            if not name.lower().endswith((".mp4", ".webm", ".ogv")):
                continue
            if file_info.get("private") == "true":
                continue
            candidates.append({
                "label": "%s (%s)" % (fmt or "Vídeo", name.rsplit(".", 1)[-1].upper()),
                "url": "https://archive.org/download/%s/%s" % (
                    urllib.parse.quote(identifier, safe=""),
                    urllib.parse.quote(name, safe="/")
                ),
                "mime": "video/mp4" if name.lower().endswith(".mp4") else "video/webm" if name.lower().endswith(".webm") else "video/ogg",
                "file_size": file_info.get("size"),
                "width": file_info.get("width"),
                "height": file_info.get("height"),
                "license": item.get("license", ""),
                "provider": self.provider_id
            })
        return candidates

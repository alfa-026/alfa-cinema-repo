# -*- coding: utf-8 -*-
"""Wikimedia Commons: busca de vídeos con licencia abierta identificada."""
import json
import re
import urllib.parse
import urllib.request

from .base import SourceProvider

API = "https://commons.wikimedia.org/w/api.php"

# Licencias que permiten reutilización; se excluyen licencias NC/ND por prudencia.
ALLOWED_LICENSE_MARKERS = (
    "creativecommons.org/publicdomain/zero",
    "creativecommons.org/licenses/by/",
    "creativecommons.org/licenses/by-sa/",
    "creativecommons.org/publicdomain/mark/",
    "creativecommons.org/licenses/publicdomain/",
)

VIDEO_EXTENSIONS = (".webm", ".ogv", ".ogg", ".mp4", ".mkv")

def _plain(value):
    if isinstance(value, dict):
        value = value.get("value", "")
    value = str(value or "")
    return re.sub(r"<[^>]+>", "", value).strip()

class CommonsProvider(SourceProvider):
    provider_id = "wikimedia_commons"
    display_name = "Wikimedia Commons — vídeos abiertos"

    def _get(self, params):
        query = urllib.parse.urlencode(params)
        url = API + "?" + query
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "ALFA-CINEMA/0.8.0 (Kodi media discovery)",
                "Accept": "application/json"
            }
        )
        with urllib.request.urlopen(req, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))

    def search(self, query, media_type="all", limit=20):
        params = {
            "action": "query",
            "format": "json",
            "formatversion": "2",
            "list": "search",
            "srnamespace": "6",
            "srlimit": str(max(1, min(int(limit), 30))),
            "srsearch": query
        }
        search_data = self._get(params)
        pages = search_data.get("query", {}).get("search", [])
        titles = [p.get("title") for p in pages if p.get("title")]
        if not titles:
            return []
        info = self._get({
            "action": "query",
            "format": "json",
            "formatversion": "2",
            "prop": "imageinfo",
            "iiprop": "url|mime|mediatype|extmetadata",
            "iiextmetadatalanguage": "es",
            "titles": "|".join(titles)
        })
        results = []
        for page in info.get("query", {}).get("pages", []):
            imageinfo = page.get("imageinfo") or []
            if not imageinfo:
                continue
            item = imageinfo[0]
            mime = (item.get("mime") or "").lower()
            media_type_value = (item.get("mediatype") or "").upper()
            source_url = item.get("url", "")
            file_title = page.get("title", "")
            if media_type_value != "VIDEO" and not mime.startswith("video/"):
                continue
            if not source_url or not source_url.lower().split("?")[0].endswith(VIDEO_EXTENSIONS):
                continue
            metadata = item.get("extmetadata") or {}
            license_url = _plain(metadata.get("LicenseUrl"))
            license_name = _plain(metadata.get("LicenseShortName"))
            lower_license = license_url.lower()
            if not any(marker in lower_license for marker in ALLOWED_LICENSE_MARKERS):
                continue
            description = _plain(metadata.get("ImageDescription")) or file_title
            artist = _plain(metadata.get("Artist"))
            results.append({
                "provider": self.provider_id,
                "provider_name": self.display_name,
                "id": file_title,
                "title": file_title.replace("File:", ""),
                "description": description,
                "author": artist,
                "license": license_name or license_url,
                "license_url": license_url,
                "web_url": item.get("descriptionurl", ""),
                "direct_url": source_url,
                "mime": mime
            })
        return results

    def resolve(self, item):
        url = item.get("direct_url")
        if not url:
            return []
        return [{
            "label": "Vídeo abierto — %s" % (item.get("mime") or "formato original"),
            "url": url,
            "mime": item.get("mime") or "video/webm",
            "license": item.get("license", ""),
            "license_url": item.get("license_url", ""),
            "provider": self.provider_id
        }]

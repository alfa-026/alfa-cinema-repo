# -*- coding: utf-8 -*-
"""Descubre complementos de vídeo ya instalados en Kodi y permite abrirlos."""
import json
import xbmc
import xbmcaddon
from .base import SourceProvider

class KodiAddonsProvider(SourceProvider):
    provider_id = "kodi_installed_addons"
    display_name = "Complementos de vídeo instalados en Kodi"

    def search(self, query="", media_type="all", limit=50):
        request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.GetAddons",
            "params": {
                "type": "xbmc.addon.video",
                "enabled": True,
                "properties": ["name", "summary", "description", "version"]
            }
        }
        raw = xbmc.executeJSONRPC(json.dumps(request))
        try:
            response = json.loads(raw)
        except Exception:
            return []
        addons = response.get("result", {}).get("addons", [])
        results = []
        q = (query or "").strip().lower()
        for addon in addons:
            addon_id = addon.get("addonid", "")
            if not addon_id or addon_id == "plugin.video.alfa.cinema":
                continue
            name = addon.get("name", addon_id)
            summary = addon.get("summary", "") or addon.get("description", "")
            # A blank query returns all installed video add-ons; otherwise filter
            # by add-on name/description without pretending to search their catalog.
            if q and q not in name.lower() and q not in summary.lower():
                continue
            results.append({
                "provider": self.provider_id,
                "provider_name": self.display_name,
                "id": addon_id,
                "title": name,
                "description": summary,
                "version": addon.get("version", ""),
                "action": "open_installed_addon"
            })
            if len(results) >= max(1, min(int(limit), 100)):
                break
        return results

    def resolve(self, item):
        addon_id = item.get("id", "")
        if not addon_id:
            return []
        try:
            xbmcaddon.Addon(addon_id)
        except Exception:
            return []
        return [{"action": "open_installed_addon", "addon_id": addon_id,
                 "label": item.get("title", addon_id)}]

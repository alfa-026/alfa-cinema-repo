# -*- coding: utf-8 -*-
"""Registro y orquestación de proveedores ALFA SOURCES."""
from .archive import ArchiveProvider
from .commons import CommonsProvider
from .youtube import YouTubeTrailerProvider
from .kodi_addons import KodiAddonsProvider

def enabled_providers(addon):
    providers = []
    if addon.getSetting("sources_installed_addons_enabled") == "true":
        providers.append(KodiAddonsProvider())
    if addon.getSetting("sources_commons_enabled") == "true":
        providers.append(CommonsProvider())
    if addon.getSetting("sources_archive_enabled") == "true":
        providers.append(ArchiveProvider())
    if addon.getSetting("sources_youtube_enabled") == "true":
        providers.append(YouTubeTrailerProvider())
    return providers

def search_all(addon, query, media_type="all", limit=25):
    results = []
    errors = []
    for provider in enabled_providers(addon):
        try:
            results.extend(provider.search(query, media_type, limit))
        except Exception as exc:
            errors.append("%s: %s" % (provider.display_name, exc))
    return results, errors

def resolve_item(addon, item):
    provider_id = item.get("provider")
    for provider in enabled_providers(addon):
        if provider.provider_id == provider_id:
            return provider.resolve(item)
    return []

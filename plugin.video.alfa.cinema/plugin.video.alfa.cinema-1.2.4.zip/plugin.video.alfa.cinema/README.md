# ALFA CINEMA v1.2.4

## Compatibilidad
Kodi 21 Omega / Python 3; Windows, Android, Linux y macOS (`platform=all`).
No requiere paquetes Python externos: usa la biblioteca estándar y las API `xbmc*` de Kodi.

## Cambios
- Añadidos `resources/__init__.py` y `resources/lib/__init__.py` para imports explícitos.
- Las importaciones internas registran y muestran traceback si fallan antes del menú.
- Se registra versión, Python y argumentos de Kodi al arrancar.
- Se elimina bytecode `.pyc`/`__pycache__` del ZIP.
- ALFA SYNC automático sigue desactivado temporalmente.

## Dependencias
`xbmc.python` 3.0.0. Sin módulos externos obligatorios.
TMDB, Trakt, Internet Archive y Wikimedia Commons son integraciones de red opcionales.

## Importante
Este paquete mejora empaquetado y diagnóstico. No puede considerarse una corrección definitiva hasta revisar el traceback real de Kodi.

# -*- coding: utf-8 -*-
"""Servicio de fondo: envía checkpoints de reproducción a ALFA SYNC."""
import time
import uuid
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib import sync_client

ADDON = xbmcaddon.Addon()
MONITOR = xbmc.Monitor()

def setting(name):
    return ADDON.getSetting(name).strip()

def ensure_device_id():
    value = setting("sync_device_id")
    if not value:
        value = str(uuid.uuid4())
        ADDON.setSetting("sync_device_id", value)
    return value

def current_media(player):
    try:
        tag = player.getVideoInfoTag()
        title = tag.getTitle() or ""
        year = tag.getYear() or 0
        media_type = tag.getMediaType() or "video"
        unique_id = ""
        try:
            unique_id = tag.getUniqueID("tmdb") or ""
        except Exception:
            pass
        if unique_id:
            content_key = "%s:tmdb:%s" % (media_type, unique_id)
        else:
            content_key = "%s:title:%s:%s" % (media_type, title.strip().lower(), year)
        return title, year, media_type, content_key
    except Exception:
        return "", 0, "video", "video:unknown"

def send_checkpoint(player, device_id, force=False):
    if not setting("sync_enabled"):
        return
    try:
        if not player.isPlayingVideo():
            return
        position = float(player.getTime())
        duration = float(player.getTotalTime())
        if duration <= 0:
            return
        title, year, media_type, content_key = current_media(player)
        if not title:
            return
        payload = {
            "device_id": device_id,
            "device_name": setting("sync_device_name") or xbmc.getInfoLabel("System.FriendlyName") or "Kodi",
            "content_key": content_key,
            "title": title[:300],
            "year": int(year or 0),
            "media_type": media_type[:30],
            "position_seconds": max(0, int(position)),
            "duration_seconds": max(0, int(duration)),
            "updated_at": int(time.time()),
            "completed": bool(duration > 0 and position / duration >= 0.95)
        }
        sync_client.push_progress(setting("sync_server_url"), setting("sync_secret"), payload)
    except Exception as exc:
        xbmc.log("ALFA CINEMA sync: %s" % exc, xbmc.LOGWARNING)

class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.last_sent = 0

    def onAVStarted(self):
        self.last_sent = 0
        send_checkpoint(self, ensure_device_id(), True)

    def onPlayBackStopped(self):
        send_checkpoint(self, ensure_device_id(), True)

    def onPlayBackEnded(self):
        send_checkpoint(self, ensure_device_id(), True)

def main():
    player = Player()
    device_id = ensure_device_id()
    while not MONITOR.abortRequested():
        if setting("sync_enabled") and player.isPlayingVideo():
            interval = max(10, min(120, int(setting("sync_interval") or "15")))
            now = time.time()
            if now - player.last_sent >= interval:
                send_checkpoint(player, device_id)
                player.last_sent = now
        if MONITOR.waitForAbort(2):
            break

if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""ALFA CINEMA v0.4.0 - catálogo TMDB + biblioteca Trakt."""
import json
import os
import sys
import time
import traceback
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

try:
    from resources.lib import tmdb, trakt, sync_client
    from resources.lib.sources import registry as source_registry
except Exception as import_exc:
    _import_traceback = traceback.format_exc()
    try:
        xbmc.log("ALFA CINEMA IMPORT ERROR: " + _import_traceback, xbmc.LOGERROR)
        xbmcgui.Dialog().textviewer(
            "ALFA CINEMA - Error al cargar módulos",
            "Kodi no ha podido cargar los módulos internos de ALFA CINEMA.\\n\\n"
            + str(import_exc) + "\\n\\n" + _import_traceback[-12000:]
        )
    except Exception:
        pass
    raise

ADDON = xbmcaddon.Addon()
xbmc.log("ALFA CINEMA START: version=%s python=%s argv=%r" % (ADDON.getAddonInfo("version"), sys.version, sys.argv), xbmc.LOGINFO)
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if sys.argv else ""
PROFILE = xbmc.translatePath(ADDON.getAddonInfo("profile"))
FAV_FILE = os.path.join(PROFILE, "favourites.json")

def notify(message):
    xbmcgui.Dialog().notification("ALFA CINEMA", message, xbmcgui.NOTIFICATION_INFO, 3500)

def api_key():
    return ADDON.getSetting("tmdb_api_key").strip()

def language():
    return {"0": "es-ES", "1": "ca-ES", "2": "en-US"}.get(ADDON.getSetting("metadata_language"), "es-ES")

def client_id():
    return ADDON.getSetting("trakt_client_id").strip()

def access_token():
    return ADDON.getSetting("trakt_access_token").strip()

def refresh_saved_token():
    refresh = ADDON.getSetting("trakt_refresh_token").strip()
    if not refresh:
        return None
    result = trakt.refresh_token(client_id(), refresh)
    ADDON.setSetting("trakt_access_token", result.get("access_token", ""))
    ADDON.setSetting("trakt_refresh_token", result.get("refresh_token", refresh))
    ADDON.setSetting("trakt_token_created", str(int(time.time())))
    if result.get("expires_in"):
        ADDON.setSetting("trakt_token_expires", str(result["expires_in"]))
    return result.get("access_token")

def valid_token():
    token = access_token()
    if not token:
        return None
    try:
        created = int(ADDON.getSetting("trakt_token_created") or "0")
        expires = int(ADDON.getSetting("trakt_token_expires") or "604800")
        if created and time.time() > created + expires - 86400:
            token = refresh_saved_token()
        return token
    except Exception:
        return token

def trakt_call(function, *args):
    token = valid_token()
    if not token:
        raise trakt.TraktError("Conecta Trakt desde el menú principal.")
    try:
        return function(client_id(), token, *args)
    except trakt.TraktError as exc:
        if exc.status == 401:
            token = refresh_saved_token()
            if token:
                return function(client_id(), token, *args)
        raise

def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)

def add_folder(label, action, **params):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(action=action, **params), li, True)

def add_video(title, media_type, item, action="details"):
    date = (item.get("release_date") or item.get("first_air_date") or "")[:4]
    plot = item.get("overview") or "Sin sinopsis disponible."
    label = ("%s (%s)" % (title, date)) if date else title
    li = xbmcgui.ListItem(label=label)
    poster = tmdb.image_url(item.get("poster_path"))
    fanart = tmdb.image_url(item.get("backdrop_path"), "w780")
    li.setArt({"thumb": poster, "poster": poster, "fanart": fanart, "icon": poster})
    li.setInfo("video", {"title": title, "year": int(date) if date.isdigit() else 0,
                         "plot": plot, "mediatype": "movie" if media_type == "movie" else "tvshow"})
    params = {"action": action, "id": item.get("id", ""), "kind": media_type,
              "title": title, "year": date, "plot": plot}
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, True)

def load_favs():
    try:
        with open(FAV_FILE, "r", encoding="utf-8") as stream:
            data = json.load(stream)
            return data if isinstance(data, list) else []
    except Exception:
        return []

def save_favs(items):
    os.makedirs(PROFILE, exist_ok=True)
    temp = FAV_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(items, stream, ensure_ascii=False, indent=2)
    os.replace(temp, FAV_FILE)

def show_error(title, exc):
    # Capture exceptions handled inside feature functions, not only at the entry point.
    details = traceback.format_exc()
    if not details or details.strip() == "NoneType: None":
        details = "%s: %s" % (type(exc).__name__, exc)
    xbmc.log("ALFA CINEMA ERROR [%s]: %s" % (title, details), xbmc.LOGERROR)
    message = (
        "ALFA CINEMA ha encontrado un error.\n\n"
        "Función: %s\n"
        "Tipo: %s\n"
        "Detalle: %s\n\n"
        "Registro técnico:\n%s"
    ) % (title, type(exc).__name__, str(exc), details[-10000:])
    try:
        xbmcgui.Dialog().textviewer("ALFA CINEMA - Diagnóstico", message)
    except Exception:
        xbmcgui.Dialog().ok(title, "%s: %s. Consulta kodi.log." % (type(exc).__name__, exc))

def home():
    add_folder("Buscar películas y series", "search")
    add_folder("Buscar fuentes en Internet", "source_search")
    add_folder("Complementos de vídeo instalados", "installed_addons")
    add_folder("Búsqueda unificada (catálogo + fuentes)", "unified_search")
    add_folder("Tendencias de Internet", "trending")
    add_folder("Películas populares", "popular", kind="movie")
    add_folder("Series populares", "popular", kind="tv")
    add_folder("Películas por año", "years_movies")
    add_folder("Series por año", "years_tv")
    add_folder("Mis favoritos locales", "favourites")
    add_folder("Progreso sincronizado", "sync_progress")
    add_folder("Biblioteca Trakt", "trakt")
    add_folder("Conectar / renovar Trakt", "connect_trakt")
    add_folder("Ajustes", "settings")
    xbmcplugin.endOfDirectory(HANDLE)

def do_search():
    term = xbmcgui.Dialog().input("Buscar título", type=xbmcgui.INPUT_ALPHANUM)
    if term:
        try:
            result = tmdb.search(term, api_key(), "multi", language())
            count = 0
            for item in result.get("results", []):
                kind = item.get("media_type")
                title = item.get("title") if kind == "movie" else item.get("name") if kind == "tv" else None
                if title:
                    add_video(title, kind, item)
                    count += 1
            if not count:
                notify("No se encontraron resultados.")
        except Exception as exc:
            show_error("Error de catálogo", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def years(kind):
    for year in range(2026, 1969, -1):
        add_folder(str(year), "year_results", year=year, kind=kind)
    xbmcplugin.endOfDirectory(HANDLE)

def year_results(year, kind):
    try:
        data = tmdb.discover_year(year, api_key(), kind, language())
        for item in data.get("results", []):
            title = item.get("title") if kind == "movie" else item.get("name")
            if title:
                add_video(title, kind, item)
    except Exception as exc:
        show_error("Error de catálogo", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def details(params):
    title = params.get("title", "Contenido")
    kind = params.get("kind", "movie")
    item_id = params.get("id", "")
    try:
        data = tmdb.details(item_id, kind, api_key(), language())
        overview = data.get("overview") or params.get("plot", "Sin sinopsis disponible.")
        date = data.get("release_date") or data.get("first_air_date") or ""
        year = date[:4]
        genres = ", ".join(g.get("name", "") for g in data.get("genres", []) if g.get("name"))
        runtime = data.get("runtime")
        if not runtime and data.get("episode_run_time"):
            runtime = data["episode_run_time"][0]
        meta = []
        if year:
            meta.append("Año: " + year)
        if genres:
            meta.append("Géneros: " + genres)
        if runtime:
            meta.append("Duración: %s min" % runtime)
        if data.get("vote_average"):
            meta.append("Valoración TMDB: %.1f/10" % float(data["vote_average"]))
        if meta:
            overview += "\n\n" + " | ".join(meta)
        xbmcgui.Dialog().textviewer(title, overview)

        choices = ["Buscar fuentes abiertas", "Añadir a favoritos"]
        if kind == "tv":
            choices.insert(0, "Ver temporadas y episodios")
        selected = xbmcgui.Dialog().select(title, choices)
        if selected < 0:
            xbmcplugin.endOfDirectory(HANDLE)
            return
        if kind == "tv":
            if selected == 0:
                show_seasons(item_id, title, data)
            elif selected == 1:
                add_favourite(item_id, kind, title, year, overview)
            elif selected == 2:
                search_sources_for_title(title)
        else:
            if selected == 0:
                search_sources_for_title(title)
            elif selected == 1:
                add_favourite(item_id, kind, title, year, overview)
    except Exception as exc:
        show_error("Ficha de contenido", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def add_favourite(item_id, kind, title, year, plot):
    favs = load_favs()
    entry = {"id": str(item_id), "kind": kind, "title": title, "year": year, "plot": plot}
    if not any(x.get("id") == str(item_id) and x.get("kind") == kind for x in favs):
        favs.append(entry)
        save_favs(favs)
        notify("Añadido a favoritos.")
    else:
        notify("Ya está en favoritos.")

def show_seasons(tv_id, show_title, show_data=None):
    try:
        if show_data is None:
            show_data = tmdb.details(tv_id, "tv", api_key(), language())
        seasons = show_data.get("seasons", [])
        visible = [s for s in seasons if int(s.get("season_number", 0)) >= 0]
        if not visible:
            xbmcgui.Dialog().ok("Temporadas", "TMDB no devuelve temporadas para esta serie.")
            return
        for season in visible:
            number = int(season.get("season_number", 0))
            name = season.get("name") or ("Temporada %s" % number)
            count = season.get("episode_count", 0)
            label = "%s — %s episodios" % (name, count)
            li = xbmcgui.ListItem(label=label)
            poster = tmdb.image_url(season.get("poster_path"))
            li.setArt({"thumb": poster, "poster": poster})
            li.setInfo("video", {"title": label, "plot": season.get("overview", "")})
            xbmcplugin.addDirectoryItem(
                HANDLE, url_for(action="season", id=tv_id, season=number, title=show_title), li, True
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        show_error("Temporadas", exc)

def show_episodes(tv_id, season_number, show_title):
    try:
        data = tmdb.season_details(tv_id, season_number, api_key(), language())
        episodes = data.get("episodes", [])
        for episode in episodes:
            number = episode.get("episode_number", 0)
            title = episode.get("name") or ("Episodio %s" % number)
            label = "E%02d — %s" % (int(number), title)
            li = xbmcgui.ListItem(label=label)
            still = tmdb.image_url(episode.get("still_path"), "w500")
            li.setArt({"thumb": still, "icon": still})
            li.setInfo("video", {"title": label, "plot": episode.get("overview", ""),
                                 "season": int(season_number), "episode": int(number)})
            xbmcplugin.addDirectoryItem(
                HANDLE,
                url_for(action="episode", id=tv_id, season=season_number, episode=number,
                        title=show_title, episode_title=title),
                li, True
            )
        if not episodes:
            li = xbmcgui.ListItem(label="No hay episodios disponibles en TMDB.")
            xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        show_error("Episodios", exc)
        xbmcplugin.endOfDirectory(HANDLE)

def episode_menu(params):
    show_title = params.get("title", "Serie")
    episode_title = params.get("episode_title", "Episodio")
    selected = xbmcgui.Dialog().select(
        episode_title,
        ["Buscar fuentes abiertas para este episodio", "Ver información del episodio"]
    )
    if selected == 0:
        search_sources_for_title("%s %s" % (show_title, episode_title))
    elif selected == 1:
        try:
            data = tmdb.episode_details(
                params.get("id"), params.get("season"), params.get("episode"), api_key(), language()
            )
            xbmcgui.Dialog().textviewer(episode_title, data.get("overview") or "Sin sinopsis disponible.")
        except Exception as exc:
            show_error("Episodio", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def search_sources_for_title(title):
    try:
        results, errors = source_registry.search_all(
            ADDON, title, "all", int(ADDON.getSetting("sources_max_results") or "25")
        )
        if not results:
            xbmcgui.Dialog().ok(
                "ALFA SOURCES",
                "No se han encontrado fuentes abiertas compatibles para este título."
            )
            return
        for item in results:
            label = "[VÍDEO ABIERTO] " + item.get("title", "Fuente")
            li = xbmcgui.ListItem(label=label)
            li.setInfo("video", {"title": item.get("title", ""), "plot": item.get("description", "")})
            xbmcplugin.addDirectoryItem(
                HANDLE, url_for(action="source_item", data=json.dumps(item, ensure_ascii=False)), li, True
            )
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        show_error("Búsqueda de fuentes", exc)

def favourites():
    for item in load_favs():
        li = xbmcgui.ListItem(label=item.get("title", "Sin título"))
        li.setInfo("video", {"title": item.get("title", ""), "plot": item.get("plot", "")})
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def connect_trakt():
    try:
        cid = client_id()
        device = trakt.request_device_code(cid)
        code, device_code = device.get("user_code"), device.get("device_code")
        if not code or not device_code:
            raise trakt.TraktError("Trakt no devolvió un código de autorización válido.")
        verify = device.get("verification_url", "https://trakt.tv/activate")
        xbmcgui.Dialog().ok("Autorizar Trakt", "Abre %s e introduce este código:\n\n[COLOR yellow]%s[/COLOR]" % (verify, code))
        progress = xbmcgui.DialogProgress()
        progress.create("ALFA CINEMA", "Esperando autorización de Trakt…")
        try:
            result = trakt.poll_device_token(
                cid, device_code, device.get("interval", 5), device.get("expires_in", 600),
                progress=lambda: progress.update(15, "Esperando confirmación…"),
                cancelled=progress.iscanceled
            )
        finally:
            progress.close()
        ADDON.setSetting("trakt_access_token", result.get("access_token", ""))
        ADDON.setSetting("trakt_refresh_token", result.get("refresh_token", ""))
        ADDON.setSetting("trakt_token_created", str(int(time.time())))
        ADDON.setSetting("trakt_token_expires", str(result.get("expires_in", 604800)))
        user = trakt.get_user(cid, result.get("access_token", ""))
        notify("Conectado como " + (user.get("username") or "usuario Trakt"))
    except Exception as exc:
        show_error("No se pudo conectar Trakt", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def trakt_menu():
    add_folder("Watchlist de películas", "trakt_data", section="watchlist", media="movies")
    add_folder("Watchlist de series", "trakt_data", section="watchlist", media="shows")
    add_folder("Colección de películas", "trakt_data", section="collection", media="movies")
    add_folder("Colección de series", "trakt_data", section="collection", media="shows")
    add_folder("Historial de películas vistas", "trakt_data", section="history", media="movies")
    add_folder("Historial de series vistas", "trakt_data", section="history", media="shows")
    add_folder("Mis listas", "trakt_data", section="lists", media="")
    add_folder("Reproducciones activas", "trakt_data", section="playback", media="")
    xbmcplugin.endOfDirectory(HANDLE)

def trakt_data(section, media):
    try:
        funcs = {
            ("watchlist", "movies"): trakt.get_watchlist,
            ("watchlist", "shows"): trakt.get_watchlist,
            ("collection", "movies"): trakt.get_collection,
            ("collection", "shows"): trakt.get_collection,
            ("history", "movies"): trakt.get_history,
            ("history", "shows"): trakt.get_history
        }
        if section == "lists":
            data = trakt_call(trakt.get_user_lists)
        elif section == "playback":
            data = trakt_call(trakt.get_playback)
        else:
            data = trakt_call(funcs[(section, media)], media)
        if not data:
            li = xbmcgui.ListItem(label="No hay elementos en esta sección.")
            xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
        else:
            for entry in data:
                obj = entry.get("movie") or entry.get("show") or entry
                title = obj.get("title") or obj.get("name") or obj.get("name") or entry.get("name") or "Elemento Trakt"
                year = obj.get("year")
                label = "%s (%s)" % (title, year) if year else title
                li = xbmcgui.ListItem(label=label)
                li.setInfo("video", {"title": title, "plot": "Datos de tu cuenta Trakt. Esta versión no reproduce contenido."})
                xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
    except Exception as exc:
        show_error("Error consultando Trakt", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def sync_progress():
    try:
        data = sync_client.get_progress(ADDON.getSetting("sync_server_url"), ADDON.getSetting("sync_secret"), 50)
        items = data.get("items", [])
        if not items:
            li = xbmcgui.ListItem(label="Todavía no hay progreso sincronizado.")
            xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
        for item in items:
            pos = int(item.get("position_seconds", 0))
            dur = int(item.get("duration_seconds", 0))
            pct = int((100.0 * pos / dur)) if dur else 0
            label = "%s — %s%%" % (item.get("title", "Contenido"), pct)
            li = xbmcgui.ListItem(label=label)
            li.setInfo("video", {"title": item.get("title", ""), "plot":
                "Último dispositivo: %s\nÚltima posición: %s s de %s s\n\nEsta vista muestra el progreso compartido; no puede reanudar el contenido sin que exista una fuente reproducible en este dispositivo." %
                (item.get("device_name", "desconocido"), pos, dur)})
            xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
    except Exception as exc:
        show_error("Sincronización ALFA", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def installed_addons():
    try:
        provider = None
        for candidate in source_registry.enabled_providers(ADDON):
            if candidate.provider_id == "kodi_installed_addons":
                provider = candidate
                break
        if provider is None:
            xbmcgui.Dialog().ok("Complementos instalados", "Activa esta opción en Ajustes > ALFA DISCOVERY.")
        else:
            items = provider.search("", "all", 100)
            if not items:
                li = xbmcgui.ListItem(label="No se han encontrado complementos de vídeo habilitados.")
                xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
            for item in items:
                label = item.get("title", item.get("id", "Complemento"))
                li = xbmcgui.ListItem(label=label)
                li.setInfo("video", {"title": label, "plot": item.get("description", "")})
                xbmcplugin.addDirectoryItem(
                    HANDLE, url_for(action="source_item", data=json.dumps(item, ensure_ascii=False)), li, True
                )
    except Exception as exc:
        show_error("Complementos instalados", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def source_search():
    term = xbmcgui.Dialog().input("Buscar fuentes gratuitas autorizadas", type=xbmcgui.INPUT_ALPHANUM)
    if not term:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    limit = int(ADDON.getSetting("sources_max_results") or "25")
    results, errors = source_registry.search_all(ADDON, term, "all", limit)
    for item in results:
        title = item.get("title", "Fuente")
        label = "[VÍDEO] [%s] %s" % (item.get("provider_name", "Fuente"), title)
        li = xbmcgui.ListItem(label=label)
        li.setInfo("video", {"title": title, "plot": item.get("description", "") or item.get("license", "")})
        xbmcplugin.addDirectoryItem(HANDLE, url_for(action="source_item", data=json.dumps(item, ensure_ascii=False)), li, True)
    if not results:
        li = xbmcgui.ListItem(label="No se encontraron fuentes abiertas compatibles.")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
    if errors:
        xbmc.log("ALFA SOURCES: " + " | ".join(errors), xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(HANDLE)

def source_item(data):
    try:
        item = json.loads(data)
        if item.get("action") == "open_installed_addon":
            addon_id = item.get("id", "")
            if not addon_id:
                raise ValueError("Identificador de complemento no válido.")
            try:
                xbmcaddon.Addon(addon_id)
                xbmc.executebuiltin("RunAddon(%s)" % addon_id)
            except Exception as exc:
                raise RuntimeError("No se pudo abrir el complemento %s: %s" % (addon_id, exc))
            xbmcplugin.endOfDirectory(HANDLE)
            return
        if item.get("action") == "youtube_search":
            try:
                xbmcaddon.Addon("plugin.video.youtube")
                query = urllib.parse.quote(item.get("query", "") + " tráiler oficial")
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.youtube/search/?q=%s)' % query)
            except Exception:
                xbmcgui.Dialog().ok("YouTube", "Instala el complemento oficial YouTube para Kodi.")
            xbmcplugin.endOfDirectory(HANDLE)
            return
        streams = source_registry.resolve_item(ADDON, item)
        if not streams:
            xbmcgui.Dialog().ok("ALFA SOURCES", "No hay un archivo de vídeo reproducible para esta ficha.")
        elif len(streams) == 1:
            play_stream(streams[0], item)
        else:
            choices = [x.get("label", "Vídeo") for x in streams]
            selected = xbmcgui.Dialog().select("Selecciona una fuente", choices)
            if selected >= 0:
                play_stream(streams[selected], item)
    except Exception as exc:
        show_error("ALFA SOURCES", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def play_stream(stream, item):
    url = stream.get("url")
    if not url:
        raise ValueError("La fuente no contiene una dirección reproducible.")
    li = xbmcgui.ListItem(label=item.get("title", "Vídeo"), path=url)
    li.setProperty("IsPlayable", "true")
    li.setMimeType(stream.get("mime", "video/mp4"))
    li.setInfo("video", {"title": item.get("title", "Vídeo"), "plot": (item.get("description", "") + "\nLicencia: " + stream.get("license", "No indicada") + "\nFormato: " + stream.get("mime", "desconocido") + "\nResolución y pistas de audio: no verificadas en esta fuente.")})
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def unified_search():
    term = xbmcgui.Dialog().input("Buscar película, serie o anime", type=xbmcgui.INPUT_ALPHANUM)
    if not term:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    media_choice = xbmcgui.Dialog().select("Tipo de contenido", ["Todo", "Películas", "Series"])
    if media_choice < 0:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    media_type = {0: "multi", 1: "movie", 2: "tv"}[media_choice]

    year_filter = ""
    if ADDON.getSetting("search_default_year_filter") == "true":
        year_filter = xbmcgui.Dialog().input("Año (opcional; dejar vacío para todos)", type=xbmcgui.INPUT_NUMERIC)

    count = 0
    errors = []
    if ADDON.getSetting("discovery_tmdb_enabled") == "true":
        try:
            langs = [language()]
            if ADDON.getSetting("search_all_title_languages") == "true":
                langs = list(dict.fromkeys(langs + ["es-ES", "ca-ES", "en-US"]))
            data, search_errors = tmdb.search_multilingual(term, api_key(), media_type, langs)
            errors.extend(search_errors)
            for item in data:
                kind = item.get("media_type")
                if kind not in ("movie", "tv"):
                    kind = "movie" if "title" in item else "tv"
                title = item.get("title") if kind == "movie" else item.get("name")
                original = item.get("original_title") if kind == "movie" else item.get("original_name")
                date = item.get("release_date") or item.get("first_air_date") or ""
                year = date[:4]
                if year_filter and year != year_filter:
                    continue
                display_title = title or original or "Sin título"
                if original and original.lower() != display_title.lower():
                    display_title = "%s — %s" % (display_title, original)
                item["_display_title"] = display_title
                add_video(display_title, kind, item)
                count += 1
        except Exception as exc:
            errors.append("Catálogo TMDB: %s" % exc)

    if ADDON.getSetting("discovery_archive_enabled") == "true":
        try:
            results, source_errors = source_registry.search_all(
                ADDON, term, media_type,
                int(ADDON.getSetting("sources_max_results") or "25")
            )
            errors.extend(source_errors)
            for item in results:
                title = item.get("title", "Fuente abierta")
                label = "[VÍDEO ABIERTO] %s" % title
                li = xbmcgui.ListItem(label=label)
                license_text = item.get("license", "Licencia no indicada")
                description = item.get("description", "")
                li.setInfo("video", {"title": title, "plot": "%s\nLicencia: %s\nFormato/calidad: se verificará en el archivo; no se presupone." % (description, license_text)})
                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    url_for(action="source_item", data=json.dumps(item, ensure_ascii=False)),
                    li, True
                )
                count += 1
        except Exception as exc:
            errors.append("Fuentes abiertas: %s" % exc)

    if count == 0:
        li = xbmcgui.ListItem(label="No se encontraron resultados con esos filtros.")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
    if errors:
        xbmc.log("ALFA DISCOVERY: " + " | ".join(errors), xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(HANDLE)

def discovery_trending():
    try:
        data = tmdb.trending(api_key(), "all", "week", language())
        for item in data.get("results", []):
            kind = item.get("media_type")
            title = item.get("title") if kind == "movie" else item.get("name") if kind == "tv" else None
            if title:
                add_video(title, kind, item)
    except Exception as exc:
        show_error("Tendencias", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def discovery_popular(kind):
    try:
        data = tmdb.popular(api_key(), kind, language())
        for item in data.get("results", []):
            title = item.get("title") if kind == "movie" else item.get("name")
            if title:
                add_video(title, kind, item)
    except Exception as exc:
        show_error("Catálogo popular", exc)
    xbmcplugin.endOfDirectory(HANDLE)

def run():
    params = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(sys.argv[2]).query))
    action = params.get("action")
    if not action:
        home()
    elif action == "settings":
        ADDON.openSettings()
        xbmcplugin.endOfDirectory(HANDLE)
    elif action == "search":
        do_search()
    elif action == "source_search":
        source_search()
    elif action == "installed_addons":
        installed_addons()
    elif action == "unified_search":
        unified_search()
    elif action == "trending":
        discovery_trending()
    elif action == "popular":
        discovery_popular(params.get("kind", "movie"))
    elif action == "source_item":
        source_item(params.get("data", "{}"))
    elif action in ("years_movies", "years_tv"):
        years("movie" if action == "years_movies" else "tv")
    elif action == "year_results":
        year_results(params.get("year", "2026"), params.get("kind", "movie"))
    elif action == "details":
        details(params)
    elif action == "season":
        show_episodes(params.get("id"), params.get("season", 0), params.get("title", "Serie"))
    elif action == "episode":
        episode_menu(params)
    elif action == "favourites":
        favourites()
    elif action == "connect_trakt":
        connect_trakt()
    elif action == "sync_progress":
        sync_progress()
    elif action == "trakt":
        trakt_menu()
    elif action == "trakt_data":
        trakt_data(params.get("section", ""), params.get("media", ""))
    else:
        xbmcgui.Dialog().ok("ALFA CINEMA", "Función todavía no implementada.")
        xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    try:
        run()
    except Exception as exc:
        details = traceback.format_exc()
        xbmc.log("ALFA CINEMA FATAL ERROR: " + details, xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().textviewer(
                "ALFA CINEMA - Error de ejecución",
                "Se ha producido un error al iniciar o ejecutar ALFA CINEMA.\n\n"
                + str(exc) + "\n\n"
                + details[-12000:]
            )
        except Exception:
            xbmcgui.Dialog().ok(
                "ALFA CINEMA - Error",
                str(exc) + "\nConsulta el registro de Kodi."
            )
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        except Exception:
            pass
